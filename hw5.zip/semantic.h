#ifndef SEMANTIC
#define SEMANTIC

void beginSemanticAnalysis(struct Node *treeHead);

#endif
